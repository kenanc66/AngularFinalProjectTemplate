import { FilterPipePipe } from './filter-pipe.pipe';

describe('FilterPipePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterPipePipe();
    expect(pipe).toBeTruthy();
  });
});
