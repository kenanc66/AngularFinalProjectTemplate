import { CartItem } from "./cartItem";

export const CartItems:CartItem[]=[];